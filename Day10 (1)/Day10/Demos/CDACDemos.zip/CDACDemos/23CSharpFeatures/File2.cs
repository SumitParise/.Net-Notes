﻿
namespace _23CSharpFeatures
{
    //developed by - prasad 
    internal partial class CMath
    {
        partial void DoValidation(string PropertyName, object PropertyValue)
        {
            switch (PropertyName) 
            {
                case "First":
                    //Some validation code
                    break;
                case "Second":
                    //some validation code
                    break;
                default:
                    break;
            }
        }
        //partial void DoValidation(int num)
        //{
        //    //some validation code 

        //}
    }
}
