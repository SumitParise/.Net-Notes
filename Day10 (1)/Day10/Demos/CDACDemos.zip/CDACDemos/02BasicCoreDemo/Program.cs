﻿using System.Reflection;

namespace _02BasicCoreDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Assembly assembly = Assembly.GetExecutingAssembly();
            Console.WriteLine("Hello, World!");
        }
    }
    //CoreFX
}
