﻿namespace _11OOPStatic
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string op = null;
            do
            {
                Console.WriteLine("Enter your DB Choice :");
                Console.WriteLine("1.Sql Server, 2.Oracle Server 3. MySQL Server");
                int dbChoice = Convert.ToInt32(Console.ReadLine());
                DataBaseFactory dataBaseFactory = new DataBaseFactory();
                IDatabase db = dataBaseFactory.GetDataBase(dbChoice);

                Console.WriteLine("Enter your DB Operation Choice:");
                Console.WriteLine("1.Insert, 2. Update,3.Delete");
                int opChoice1 = Convert.ToInt32(Console.ReadLine());
                switch (opChoice1)
                {
                    case 1:
                        db.Insert();
                        break;
                    case 2:
                        db.Update();
                        break;
                    case 3:
                        db.Delete();
                        break;
                    default:
                        break;
                }
                Console.WriteLine("Do you want to continue? y/n");
                op = Console.ReadLine();
            } while (op != "n");
        }


    }
    public interface IDatabase
    {
        void Insert();
        void Update();
        void Delete();
    }
   
    //Factory Pattern
    public class DataBaseFactory //Factory Classes
    {
        public IDatabase GetDataBase(int dbChoice)//Factory Methods
        {
            if (dbChoice == 1)
            {
                return new SQLServer();
            }
            else if (dbChoice == 2)
            {
                return new OracleServer();
            }
            else if (dbChoice == 3)
            {
                MySQLServer mysqlObj = new MySQLServer();
                return mysqlObj;
            }
            else
            {
                return null;
            }
        }
    }
    public class SQLServer : IDatabase
    {
        private Logger logger = null;
        public SQLServer()
        {
            logger = Logger.GetLogger();
        }
        public void Insert()
        {
            Console.WriteLine("Data Inserted into SQL Server Successfully!!");
            logger.Log("Insert in SQLServer Done");
        }
        public void Update()
        {
            Console.WriteLine("Data Updated into SQL Server Successfully!!");
            logger.Log("Update in SQLServer Done");
        }
        public void Delete()
        {
            Console.WriteLine("Data Delete into SQL Server Successfully!!");
            logger.Log("Delete in SQLServer Done");
        }
    }
    public class OracleServer : IDatabase
    {
        private Logger logger = null;
        public OracleServer()
        {
            logger = Logger.GetLogger();
        }
        public void Insert()
        {
            Console.WriteLine("Data Inserted into Oracle Server Successfully!!");
            logger.Log("Insert in OracleServer Done");
        }
        public void Update()
        {
            Console.WriteLine("Data Updated into Oracle Server Successfully!!");
            logger.Log("Update in OracleServer Done");
        }
        public void Delete()
        {
            Console.WriteLine("Data Delete into Oracle Server Successfully!!");
            logger.Log("Delete in OracleServer Done");
        }
    }
    public class MySQLServer : IDatabase
    {
        private Logger logger = null;
        public MySQLServer()
        {
            logger = Logger.GetLogger();
        }
        public void Insert()
        {
            Console.WriteLine("Data Inserted into MySQL Server Successfully!!");
            logger.Log("Insert in MySql Done");

        }
        public void Update()
        {
            Console.WriteLine("Data Updated into MySQL Server Successfully!!");
            logger.Log("Update in MySql Done");
        }
        public void Delete()
        {
            Console.WriteLine("Data Delete into MySQL Server Successfully!!");
            logger.Log("Delete in MySql Done");
        }
    }
    //Single Responsibility Pattern
    public class Logger //Singleton
    {
        private static Logger logger = new Logger();
        //private static Logger logger1 = new Logger();
        private Logger()
        {
            
            Console.WriteLine("---Logger Object Created For First Time ---");
        }
        public static Logger GetLogger()
        {
            return logger;
        }
        //public static Logger GetLogger1()
        //{
        //    return logger1;
        //}
        public void Log(string msg)
        {
            Console.WriteLine("--- Logged msg {0} at {1}", msg, DateTime.Now.ToString());
        }
    }
}
