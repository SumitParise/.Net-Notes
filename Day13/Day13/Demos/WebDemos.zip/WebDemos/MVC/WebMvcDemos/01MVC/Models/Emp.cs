﻿namespace _01MVC.Models;

public class Emp
{
    public int No { get; set; }
    public string ?Name { get; set; }
    public string ?Address { get; set; }
}
