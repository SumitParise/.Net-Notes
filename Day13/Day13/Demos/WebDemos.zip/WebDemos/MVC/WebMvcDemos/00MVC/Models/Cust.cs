﻿namespace _00MVC.Models
{
    public class Cust
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Address { get; set; }
    }
}
