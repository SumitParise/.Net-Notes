﻿using System;

namespace _22CSharpFeatures
{
    internal partial class CMath
    {
        public int Sub(int x, int y)
        {
            return x - y;
        }
    }
}
