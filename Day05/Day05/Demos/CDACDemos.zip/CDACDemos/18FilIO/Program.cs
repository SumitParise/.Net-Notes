﻿using System.Runtime.Serialization.Formatters.Binary;

namespace _18FilIO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"D:\IETCDAC\MyData.txt";

            #region StreamWriter 
            //FileStream fs = new FileStream(filePath,
            //                            FileMode.OpenOrCreate | FileMode.Append,
            //                            FileAccess.Write);
            //StreamWriter write = new StreamWriter(fs);
            //Console.WriteLine("Enter thye text");
            //string txt = Console.ReadLine();
            //write.WriteLine(txt);
            //write.AutoFlush = true;
            //write.Close();
            //fs.Close();
            //Console.WriteLine("Done"); 
            #endregion

            #region StteamReader
            //FileStream fs=new FileStream(filePath,FileMode.Open,FileAccess.Read);
            //StreamReader sr =new StreamReader(fs);
            //string opData= sr.ReadToEnd();
            //Console.WriteLine(opData); 
            #endregion

            #region Persist Object in txt using StreamWrite Class
            //string filePath1 = @"D:\IETCDAC\MyData1.txt";
            //FileStream fs = null;
            //if (File.Exists(filePath))
            //{
            //    fs = new FileStream(filePath1, FileMode.Append, FileAccess.Write);
            //}
            //else
            //{
            //    fs = new FileStream(filePath1, FileMode.CreateNew, FileAccess.Write);
            //}
            //Customer customer = new Customer();
            //Console.WriteLine("Enter ID :");
            //customer.Id = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Enter name ");
            //customer.CName = Console.ReadLine();
            //Console.WriteLine("Enter address");
            //customer.CAddress = Console.ReadLine(); 


            //StreamWriter write = new StreamWriter(fs);
            //write.Write(customer);
            //write.AutoFlush = true;
            //write.Close();
            //fs.Close();
            //Console.WriteLine("Done"); 
            #endregion

            string filePath1 = @"D:\IETCDAC\MyData1.txt";
            FileStream fs = null;
            if (File.Exists(filePath))
            {
                fs = new FileStream(filePath1, FileMode.Append, FileAccess.Write);
            }
            else
            {
                fs = new FileStream(filePath1, FileMode.CreateNew, FileAccess.Write);
            }
            Customer customer = new Customer();
            Console.WriteLine("Enter ID :");
            customer.Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter name ");
            customer.CName = Console.ReadLine();
            Console.WriteLine("Enter address");
            customer.CAddress = Console.ReadLine();

            //Serializtion :Converting complex Object data into some other form*
            //so that we can transfer it over the network or we can persist it
            //on hard drive.
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fs,customer);
            fs.Close();
            Console.WriteLine("Done");

        }
    }
    public class Customer
    {
        private int _CId;
        private string _CName;
        private string _CAddress;

        public string CAddress
        {
            get { return _CAddress; }
            set { _CAddress = value; }
        }


        public string CName
        {
            get { return _CName; }
            set { _CName = value; }
        }


        public int Id
        {
            get { return _CId; }
            set { _CId = value; }
        }
        public string GetCustomerDetails()
        {
            string str = "CID "+_CId + "CName "+ _CName+ " CAddress " + _CAddress;
            return str;
        }
    }
}

// Logger class - Log method.. 
//Write Log int muLog.txt file 
