﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace _26AdoNETDisconnected
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string _connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=Cdac;Integrated Security=True;Pooling=False;Encrypt=True;Trust Server Certificate=False";

            SqlConnection connection=new SqlConnection( _connectionString );
            //Disconnected Architecture
            //Open the connection , will fire the select query,
            //will read and bring all db records from db  and
            //it will close the connection
            //and it will initialize DataTable Collection for us
            SqlDataAdapter da =new SqlDataAdapter("select * from Emp",connection);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey; // this fetches Primary Key info from SqlDB
            DataTable table = new DataTable("Emp");
            da.Fill(table);
            // DataTable --> collection of DataRows -- > collection DataColumns
            foreach (DataRow row in table.Rows) 
            {
                string op = string.Format("No ={0}, Name ={1}, Address ={2}",
                                                                    row[0], row["Name"],
                                                                    row["Address"]);
                Console.WriteLine(op);
            }
        }
    }
}
